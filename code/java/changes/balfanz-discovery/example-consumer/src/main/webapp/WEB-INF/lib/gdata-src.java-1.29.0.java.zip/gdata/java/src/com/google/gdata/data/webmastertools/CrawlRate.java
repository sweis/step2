/* Copyright (c) 2008 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.google.gdata.data.webmastertools;

/**
 * CrawlRate is an enumerated type that indicates the desired crawl rate
 * to use for a concrete site. Not all rates may be allowed for a given site. 
 * 
 * 
*/
public enum CrawlRate {
  
  SLOWEST("slowest"),
  SLOWER("slower"),
  NORMAL("normal"),
  FASTER("faster"),
  FASTEST("fastest"),
  ;

  private String value;

  /**
   * Constructor. Associates a string with the enum value.
   * 
   * @param associatedString the string associated with the crawl rate value.
   */
  private CrawlRate(String associatedString) {
    value = associatedString;
  }

  /**
   * Returns the string representation of the CrawlRate.
   */
  @Override
  public String toString() {
    return value;
  }
  
  /**
   * Returns the default CrawlRate value.
   * 
   * @return default CrawlRate value.
   */
  public static CrawlRate getDefault() {
    return NORMAL;
  }
  
  /**
   * Parse a string and return a crawl rate.
   * 
   * @param value a string representing a crawl rate.
   * @return a CrawlRate if the parameter can be successfully parsed.
   * @throws IllegalArgumentException if the parameter is not a valid
   * CrawlRate string.
   */
  public static CrawlRate fromString(String value) 
      throws IllegalArgumentException {
    for (CrawlRate rate : values()) {
      if (rate.toString().equals(value)) {
        return rate;
      }
    }
    
    throw new IllegalArgumentException(
        "The parameter is not a valid CrawlRate string");
  }
}